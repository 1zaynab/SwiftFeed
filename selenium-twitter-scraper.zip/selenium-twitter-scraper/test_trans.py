from deep_translator import GoogleTranslator

from transformers import AutoModelForSequenceClassification, TFAutoModelForSequenceClassification
from transformers import AutoTokenizer


MODEL = f"cardiffnlp/tweet-topic-21-multi"
tokenizer = AutoTokenizer.from_pretrained(MODEL)

# PT
model = AutoModelForSequenceClassification.from_pretrained(MODEL)
class_mapping = model.config.id2label

input_txt = "Salut! Je m'appelle Ali"
print(input_txt)
translated_text = GoogleTranslator(source='auto', target='en').translate(input_txt)
print(translated_text)

# google meet code: tcy-hjwy-fhs aw give me ur email to invite you


# New simplified mapping
new_class_mapping = {
    'arts_&_culture': 'Arts',
    'business_&_entrepreneurs': 'Business',
    'celebrity_&_pop_culture': 'Celebrity',
    'diaries_&_daily_life': 'Diaries',
    'family': 'Family',
    'fashion_&_style': 'Fashion',
    'film_tv_&_video': 'Film & TV',
    'fitness_&_health': 'Fitness',
    'food_&_dining': 'Food',
    'gaming': 'Gaming',
    'learning_&_educational': 'Education',
    'music': 'Music',
    'news_&_social_concern': 'News',
    'other_hobbies': 'Hobbies',
    'relationships': 'Relationships',
    'science_&_technology': 'Science',
    'sports': 'Sports',
    'travel_&_adventure': 'Travel',
    'youth_&_student_life': 'Youth'
}


tokens = tokenizer(translated_text, return_tensors='pt')
output = model(**tokens)



predicted_index = output.logits.argmax(-1).item()  # Get the index of the highest probability
original_category = class_mapping[predicted_index]
new_category = new_class_mapping[original_category]

# print("Original Category:", original_category)
# print("Mapped Category:", new_category)
original_category = class_mapping[predicted_index]
print(original_category)
