

data = {
    'Content': ['hello #cat here we #go', 'test #project etc'],
    'Tags' : []
}


hashtags = []
for tweet in data['Content']:
    current = ''
    for word in tweet.split(' '):
        if word.startswith('#') :
            current = current + word + " "

    hashtags.append(current.strip())


data['Tags']= hashtags

print(data)


"""         # Classify each tweet and add the category to the data
    categories = []
    for content in data["Content"]:
        category = model.predict([content])[0]
        categories.append(category)
    data["Category"] = categories """

""" #tweet_classifier.joblib

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score
import joblib

# Load your dataset
df = pd.read_csv(csv_file_path)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(df['Content'], df['Category'], test_size=0.2, random_state=42)

# Create a pipeline that vectorizes the text and then applies logistic regression
model = make_pipeline(TfidfVectorizer(), LogisticRegression())

# Train the model
model.fit(X_train, y_train)

# Evaluate the model
predictions = model.predict(X_test)
print(f'Accuracy: {accuracy_score(y_test, predictions)}')

# Save the model
joblib.dump(model, 'tweet_classifier.joblib')
 """
